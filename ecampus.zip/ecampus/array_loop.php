<?php 

$aplikasi[1] = 'gtAkademik';
$aplikasi[2] = 'gtFinansi';
$aplikasi[3] = 'gtPerizinan';
$aplikasi[4] = 'gtCampuz';
$aplikasi[5] = 'gtOviz';

$i = 1;

while ($i <= 5) {
	echo "Aplikasi ke -".$i." = ".$aplikasi[$i];
	echo "</br>";
	$i++;
}

?>
